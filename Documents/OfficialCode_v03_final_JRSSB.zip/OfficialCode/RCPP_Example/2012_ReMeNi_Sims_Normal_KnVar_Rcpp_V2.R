# The puprose of this code is to use MCMC+importance sampling to 
# better understand the computation time of our methodology

rm(list=ls())
#library(doParallel)
library(compiler)
set.seed(2012)
 
#dir = "~/Dropbox/2012_ReMeNi_codes/"
#dir= "F:/Dropbox/2012_ReMeNi_codes/"
#sourceCpp("~/Dropbox/2012_ReMeNi_codes/fast_loop.cpp")
#sourceCpp(paste(dir,"fast_loop.cpp",sep=""))
library(Rcpp)
sourceCpp("fast_loop.cpp")

#cl<-makeCluster(4)
#registerDoParallel(cl)



trim=0
n<-100
k_max<-50

#k_max<-1000

#For Paper
reps<-100 #1000
mc_len=10000 #100000

#For Testing
#reps=100
#mc_len=1000

#rep_blocks_size=reps
#rep_blocks_cnt = reps/rep_blocks_size
# Number of k to plot
k_plot<-40



# true paramters #
mu<-1
sigma<-1

# We assume that mu is normal and sigma is known. 
# Taking all parameters zero would yield a 
# noninformative prior, but it would also be improper. 

# hyper parameters #
# lambda is the prior mean, tau is the prior sd
lambda_all <- c(1,1.5,2,3)
tau_all <- sqrt(c(.25,.25,.25,.25))
#lambda_all<-3
#tau_all<-sqrt(.25)

lambdab<-1
# under the base line taub is inf


### Data Generating Prior and Model ###
X<- rnorm(n,mean= mu, sd = sigma) 

all<-length(lambda_all)
U<-matrix(nrow=all,ncol=(1+k_plot/2))
Ub<-matrix(nrow=all,ncol=(k_plot/2))
M<-matrix(nrow=all,ncol=(k_plot/2))


start_time<-proc.time()[3]
myfunc<-function(ii){	
  #library(Rcpp)
  #direc = "~/Dropbox/2012_ReMeNi_codes/"
  #direc= "F:/Dropbox/2012_ReMeNi_codes/"
  #sourceCpp(paste(direc,"fast_loop.cpp",sep=""))
  
  Utmp<-numeric(1+k_plot/2)
  Ubtmp<-numeric(k_plot/2)
  Mtmp<-numeric(k_plot/2)	
  # mu hyper parameters #
  lambda <- lambda_all[ii]
  tau <- tau_all[ii]
  
  prior_mean<- lambda
  prior_var<- tau^2
  
  #post_mean_k<-numeric(0)
  #post_mean_kb<-numeric(0)
  
  post_mean_diff_k<-numeric(0)
  post_mean_diff_kb<-numeric(0)
  post_var_k<-numeric(0)
  post_var_kb<-numeric(0)
  
  muhat<-mean(X)
  #Accept_rate<-numeric(k_max)
  
  # MC Sample
  mc_lambda=mean(X)
  mc_tau<- (1/( 1/sigma^2))^{1/2}
  mc_sample<-rnorm(mc_len,mean=mc_lambda, sd = mc_tau) 
  mc_weight<-dnorm(mc_sample,mean=mc_lambda,sd=mc_tau)
  
  
  # to get all in C++ we need
  # X, k_max, reps, 
  # mc_sample, mc_weight
  # tau, sigma, lambda
  
  
  Out_matrix <- fast_loop(X,k_max,reps,muhat,mc_sample,mc_weight,sigma,lambda,tau)
  #Out_matrix<-matrix(0,nrow=k_max,ncol=4)
  post_mean_diff_k <-c(Out_matrix[,1])
  post_mean_diff_kb <-c(Out_matrix[,2])
  post_var_k <-c(Out_matrix[,3])
  post_var_kb <-c(Out_matrix[,4])
  wt_var_prior<-c(Out_matrix[,5])
  wt_var_base<-c(Out_matrix[,6])
  
  #Compute the estimated mean squared errors#
  
  post_mse_k<-post_var_k + post_mean_diff_k #(post_mean_k - muhat)^2
  post_mse_kb<-post_var_kb + post_mean_diff_kb # (post_mean_kb - muhat)^2
  prior_mse<-prior_var +(prior_mean - muhat)^2
  
  
  
  Utmp[1]<-prior_mse
  Utmp[-1]<-post_mse_k[1:(k_plot/2)]
  
  Ubtmp<-post_mse_kb[1:(k_plot/2)]
  
  
  # Next we use the graphs to determine the  
  # effective sample size of the prior.
  # We will look at how many more subjects 
  # it takes for the baseline to reach the 
  # prior plus some number of subjects.
  lb<-numeric(0)
  ub<- numeric(0)
  #ub0<-min(which(post_var_kb<prior_var)[-1]) 
  lb0<-max(which(post_mse_kb>=prior_mse))
  if(lb0==-Inf)(lb0=0)
  ub0<-lb0+1
  impsamp<-numeric(0)
  for(j in 1:(k_plot/2)){
    tmp<-max(which(post_mse_kb>post_mse_k[j])) # find last time prior is above baseline
    if(tmp==-Inf){tmp<-1}
    lb[j]<-tmp - j 
    impsamp[j]<-lb[j]+(post_mse_kb[tmp]-post_mse_k[j])/(post_mse_kb[tmp]-post_mse_kb[tmp+1])
    remove(tmp)
  }
  ub<-lb+1
  inty<-max(c(prior_mse,post_mse_kb[3:k_plot]))
  
  tmpx<-(1:(k_plot/2))
  tmp<-lm(impsamp ~ tmpx)
  Mtmp<-impsamp
  tmplab<-paste("k (Slope = ",round(tmp[[1]][2],digits=4),")",sep="")
  #plot(impsamp,main="",xlab=tmplab,ylab="Imputed Sample Size")
  #abline(tmp)
  #lnsm<-ksmooth(tmpx,impsamp,kernel="normal",bandwidth=30)
  #points(lnsm,type="l",col=2,lwd=2)
  #abline(h=-53,col=2)
  #axis(4,at=-53)
  remove(tmp)
  remove(tmpx) 
  
  #dev.off()
  return(list(Utmp,Ubtmp,Mtmp,wt_var_prior,wt_var_base))
}


# reps = 100, mc_len = 100000
# 66 seconds with all c++
# 77 seconds with some c++
# 115.134 seconds with original
# system.time(myfunc(1))

#Res<-foreach(ii = 1:all) %dopar% myfunc(ii)
#stopCluster(cl)
Res<-foreach(ii = 1:all) %do% myfunc(ii)
end_time<-proc.time()[3]


Slp<-numeric(all)
tmpx<-(1:(k_plot/2))
#Accept_rate<-matrix(,nrow=all,ncol=k_max)

for(i in 1:all){
	U[i,]<-Res[[i]][[1]]
	Ub[i,]<-Res[[i]][[2]]
	M[i,]<-Res[[i]][[3]]
	Slp[i]<-lm(M[i,] ~ tmpx)[[1]][2]
	#Accept_rate[i,]<-Res[[i]][[4]]
}





dev.new(width=12,height=6)
par(mfrow=c(1,2))
#start<-k_plot/2-k_plot/2+1
start<-1


md<-(min(M,na.rm=TRUE)+max(M,na.rm=TRUE))/2
ylm<-c(min( c(M[,start:(k_plot/2)]) ,na.rm=TRUE),max(M[,start:(k_plot/2)],na.rm=TRUE))
plot(M[1,],ylim=ylm,xlim=c(start,k_plot/2),pch=1,type='b',col=1,xlab="",ylab="")
for(i in 2:all){
	points(M[i,],pch=i,col=i,type='b')
}

start<-6
tmpx<-(start:(k_plot/2))
for(i in 1:all){
	Slp[i]<-lm(M[i,start:(k_plot/2)] ~ tmpx)[[1]][2]
	}
Slp; M[,1];
#start<-1

ltmp<-sprintf("%.1f",round(lambda_all,2))
Stmp<-sprintf("%.3f",round(Slp,digits=3))
leg<-c(paste("Mean= ",ltmp, ", Slope= ", Stmp,sep=""))
legend(x=1,y=-8,legend=leg,col=1:all,pch=1:all)
# "-0.082" "-0.080" "-0.736" "0.002"  "-0.925"


ylm<-c(min( c(c(U[,start:(k_plot/2)]),c(Ub[,start:(k_plot/2)])) ,na.rm=TRUE),max(c(c(U[,start:(k_plot/2)]),c(Ub[,start:(k_plot/2)])),na.rm=TRUE))
plot((start:(k_plot/2)),U[1,start:(k_plot/2)],ylim=ylm,xlim=c(start,(k_plot/2)),type='l',col=1,xlab="",ylab="")
points((start:(k_plot/2)),Ub[1,start:(k_plot/2)],type='l',col=1,lty=2)
for(i in 2:all){
	points((start:(k_plot/2)),U[i,start:(k_plot/2)],type='l',col=i)
	points((start:(k_plot/2)),Ub[i,start:(k_plot/2)],type='l',col=i,lty=2)
}
ltmp<-sprintf("%.1f",round(lambda_all,2))
Stmp<-sprintf("%.3f",round(Slp,digits=3))
leg<-c(paste("Mean= ",ltmp, ", Slope= ", Stmp,sep=""))
legend(x=10,y=ylm[2],legend=leg,col=1:all,pch=1:all)



Table<-data.frame(lambda_all,tau_all,round(Slp,digits=3),round(M[,20]/20,digits=3))
library(xtable)
print(xtable(Table,digits=c(1,1,1,3,3)),include.rownames=FALSE,include.colnames=FALSE)


end_time-start_time

# 14.832 for 10 reps
# 46.986 for 50
# 84.674 for 100
# Est for 10000 8467 sec or 2.35 hours
# Act for 10000 8434 sec or 2.34 hours

# Look at effective MC sample size
M_eff_prior<-matrix(nrow=all,ncol=k_max)
M_eff_base<-matrix(nrow=all,ncol=k_max)
for(i in 1:all){
	M_eff_prior[i,] = mc_len/(1+Res[[i]][[4]])
	M_eff_base[i,] = mc_len/(1+Res[[i]][[5]])
}

mc_len;
c(min(M_eff_prior),max(M_eff_prior)); c(min(M_eff_prior),max(M_eff_prior))/mc_len
c(min(M_eff_base),max(M_eff_base));c(min(M_eff_base),max(M_eff_base))/mc_len






