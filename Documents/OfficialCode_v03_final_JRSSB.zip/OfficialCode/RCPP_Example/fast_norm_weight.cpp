#include <Rcpp.h> 
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector fast_norm(NumericVector mc_sample, NumericVector mc_weight, NumericVector mu, double sigma) {
    int n = mu.size();
    int mc_len = mc_sample.size();
    NumericVector out(n);
    NumericVector new_weight(mc_len);
    for (int i = 0; i < n; ++i){
        new_weight = dnorm(mc_sample,mu(i),sigma);
        out(i)=mean(new_weight*mc_sample/mc_weight);
    }
    return(out);
} 
