// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadilloExtensions/sample.h>

using namespace Rcpp;

// [[Rcpp::export]]
NumericVector fast_loop(NumericVector X, int k_max, int reps, double muhat,
                        NumericVector mc_sample, NumericVector mc_weight,
                        double sigma, double lambda, double tau) {
    NumericVector post_mean_diff_k(k_max);
    NumericVector post_var_k(k_max);
    NumericVector post_mean_diff_kb(k_max);
    NumericVector post_var_kb(k_max);
    NumericVector wt_var_prior(k_max);
    NumericVector wt_var_base(k_max);
    
    
    for(int k = 0; k<k_max; ++k){
        double tau_prior = 1/sqrt(1/(tau*tau) + (k+1)/(sigma*sigma));
        double tau_base = sigma/sqrt(k+1);
        double post_lambda =0;
        double post_lambdab =0;
        for(int i_reps = 0; i_reps<reps;++i_reps){
            double mean_X_k = mean(RcppArmadillo::sample(X,(k+1),TRUE));
            double post_lambda_prior = (lambda/(tau*tau)+(k+1)*mean_X_k/(sigma*sigma))/(1/(tau*tau)+ (k+1)/(sigma*sigma));
            double post_lambda_base = mean_X_k;
            NumericVector weight_prior = dnorm(mc_sample,post_lambda_prior,tau_prior)/mc_weight;
            NumericVector weight_base = dnorm(mc_sample,post_lambda_base,tau_base)/mc_weight;
            double mn_pr_tmp = mean(weight_prior);
            double mn_bs_tmp = mean(weight_base);
            weight_prior = weight_prior/mn_pr_tmp;
            weight_base = weight_base/mn_bs_tmp;
            post_lambda =post_lambda + mean(mc_sample*weight_prior);
            post_lambdab = post_lambdab + mean(mc_sample*weight_base);
            wt_var_prior(k) = wt_var_prior(k) + (mean(weight_prior*weight_prior)-mean(weight_prior)*mean(weight_prior))*mn_pr_tmp*mn_pr_tmp;
            wt_var_base(k) = wt_var_base(k) + (mean(weight_base*weight_base)-mean(weight_base)*mean(weight_base))*mn_bs_tmp*mn_bs_tmp;
        }
        post_lambda = post_lambda/reps;
        post_lambdab = post_lambdab/reps;
        wt_var_prior(k) = wt_var_prior(k)/reps;
        wt_var_base(k) = wt_var_base(k)/reps;
        
        post_mean_diff_k(k) = (post_lambda - muhat)*(post_lambda - muhat);
        post_mean_diff_kb(k) = (post_lambdab - muhat)*(post_lambdab - muhat);
        post_var_k(k) = tau_prior*tau_prior;
        post_var_kb(k) = tau_base*tau_base;
    }
    NumericMatrix out(k_max,6);
    out(_,0) = post_mean_diff_k;
    out(_,1) = post_mean_diff_kb;
    out(_,2) = post_var_k;
    out(_,3) = post_var_kb;
    out(_,4) = wt_var_prior;
    out(_,5) = wt_var_base;
    return(out);
}