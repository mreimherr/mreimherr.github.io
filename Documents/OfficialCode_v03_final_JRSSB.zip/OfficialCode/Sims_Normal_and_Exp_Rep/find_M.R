# calculates first zeros of discretely observed objects
find_M<-function(U,ku,Ub,kb,ngrid=1000,k=20){
  
  #ngrid<-1000
  #k<-20
  #ku<-1:60
  #kb<-10:60
  #U<-(ku+5)^-1
  #Ub<-(kb)^-1
  
  # List of checks to make sure input is reasonable
  # In general, U should be lower than Ub point-wise
  if(min(U)>max(Ub)){warning("U is completely above Ub, something very wrong")}
  if(max(U)<min(Ub)){warning("U is completely below Ub")}
  
  # Interpolate
  Ugrid<-seq(min(ku),max(ku),length=ngrid)
  Uint<-approx(ku,U,xout=Ugrid)$y
  Ubgrid<-seq(min(kb),max(kb),length=ngrid)
  Ubint<-approx(kb,Ub,xout=Ubgrid)$y
  
  M_grid<-max(kb[1],ku[1]):k
  M<-numeric(length(M_grid))
  for(i in 1:length(M_grid)){
    Uspt<-which.min(abs(Ugrid-M_grid[i])) # which point corresponds to "k"
    Ubspt<-which.min(abs(Ubint-Uint[Uspt])) #which point corresponds to "M+k"
    M[i] = Ubgrid[Ubspt] - Ugrid[Uspt]
    if(Ubspt==length(Ubgrid) | Uspt==length(Ugrid)){warning("End/boundary reached when computing M")}
  }
  
  mylist<-list(M=M,k=M_grid)
}