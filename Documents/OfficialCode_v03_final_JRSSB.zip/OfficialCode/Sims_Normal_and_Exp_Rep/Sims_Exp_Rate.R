##########################
# Simulation scheme with exponential data 
# prior is placed on the mean
##########################

# Clean out workspace
rm(list=ls())
plots_only<-FALSE
ave_reps<-1000
#cl_node_type <- "multiple"
cl_node_type <- "single"

#library(abind) 
source("find_M.R")

# We set the seed so that all plots are reporducible
myseed<-2012
set.seed(myseed)

# n is the sample size of the data
# note quite as robust as normal, but looks good after 15
n_all<-1000

cv_sample<-FALSE # if true then sample is divided 
usetruth<-FALSE # if true then truth is used, cv_sample is ignored
# exact U and M, cv_sample and use_truth are ignored
perm<-FALSE # True=permutation, False = bootstrap, not implemented alwasy boot

cv_prop<-0.5 # prop to leave out for estimating "truth"
if(cv_sample==TRUE & usetruth!=TRUE){
  n_cv<-round(cv_prop*n_all)
  n<-n_all - n_cv
}else{
  n<-n_all
}

# k_max controls the largest value of k when
# computing the uncertaing functions U(k)
k_plot<- n_all/2
k_max<- n_all
k_beg<-3

# Number of k to plot
# note that we actually plot k_plot/2
# so plan accordingly 


# Number of bootstrap samples
reps<-100000

# True parameter values
#mu<-1/2
lambda<-2

## We take a gamma prior on mu
# baseline hyper prarameters
alphab<-0
betab<-0

# New Parametrization #
# prior hyper parameters 
Delta_all<-c(0,0.5,1,1.25)
r_all<-c(1,1,1,1)*.05

Sig2_post_base<- lambda^2/n
mean_post_base<- lambda

sd_all = sqrt( Sig2_post_base / r_all )
mean_all = mean_post_base + sd_all*Delta_all 


# Setup up functions to convert alpha and beta
# to mean and variance.
mn_f<-function(alpha,beta){
  tmp<-numeric(length(alpha))
  for(i in 1:length(alpha)){
    if(alpha[i] >0){tmp[i] = (alpha[i]/beta[i])
    }else{tmp[i] = Inf}
  }
  return(tmp)
}
vr_f<-function(alpha,beta){
  tmp<-numeric(length(alpha))
  for(i in 1:length(alpha)){ 
    if(alpha[i] >0){tmp[i] = (alpha[i]/beta[i]^2)
    }else{tmp[i]=Inf}
  }
  return(tmp)
}
alp_f<-function(mnf,vrf){mnf^2/vrf}
bet_f<-function(mnf,vrf){mnf/vrf}

alpha_all<-alp_f(mean_all,sd_all^2)
beta_all<-bet_f(mean_all,sd_all^2)


#for(i_ave_reps in 1:ave_reps){
myfunc_2<-function(i_ave_reps){    
  X<-rexp(n,rate = lambda) 
  if(cv_sample==TRUE & usetruth!=TRUE ){
    X_cv<-rexp(n_cv,rate = lambda) 
  }
  
  # We now setup a function that we can parallelize
  # this function computes the Us for a given prior
  myfunc<-function(ii){
    
    # Prior parameters
    alpha0<-alpha_all[ii] #alpha0<-mn^2/vr
    beta0<-beta_all[ii]  #beta0<-mn/vr
    mn<-mn_f(alpha0,beta0)
    vr<-vr_f(alpha0,beta0)
    prior_mean<-mn_f(alpha0,beta0)          #(alpha0)/(beta0)
    prior_var<- vr_f(alpha0,beta0)          #(alpha0)/(beta0)^2
    
    post_mean<-mn_f(alpha0+n,beta0+sum(X))   #(alpha0 + n)/(beta0+sum(X))
    post_var<- vr_f(alpha0+n,beta0+sum(X))   #(alpha0 + n)/(beta0+sum(X))^2
    lambdahat<-mn_f(alphab+n,betab+sum(X))      
    if(cv_sample==TRUE & usetruth!=TRUE ){
      lambdahat<-mn_f(alphab+n_cv,betab+sum(X_cv))      
    }
    if(usetruth==TRUE ){lambdahat=lambda}
    
    # we keep track of the posterior means and variance
    # for the the prior and baseline

    
      
    sum_X_k <- t(apply(matrix(sample(X,size=k_max*reps,replace=!perm),nrow=reps,ncol=k_max),1,cumsum)) 
    post_beta<-beta0+sum_X_k
    post_beta_b<-betab+sum_X_k
    post_mean_diff_k <- colMeans((scale(1/post_beta,center=FALSE,scale=1/(alpha0 +1:k_max)) - lambdahat)^2)
    post_mean_diff_kb <- colMeans((scale(1/post_beta_b,center=FALSE,scale=1/(alphab +1:k_max)) - lambdahat)^2)
    post_var_k<-colMeans(scale(1/post_beta^2,center=FALSE,scale=1/((alpha0 +1:k_max)   )))
    post_var_kb<-colMeans(scale(1/post_beta_b^2,center=FALSE,scale=1/((alphab  +1:k_max))   ))
  
    post_mse_k<-post_var_k + post_mean_diff_k 
    post_mse_kb<-post_var_kb + post_mean_diff_kb 
    
    U<-post_mse_k[-(1:(k_beg-1))]; ku<-(k_beg):k_max
    Ub<-post_mse_kb[-(1:(k_beg-1))]; kb<-(k_beg):k_max
    ngrid=100000
    my_M<-find_M(U,ku,Ub,kb,ngrid,k=k_plot)
    
    # Approximation
    rhat <- vr_f(alphab +n,betab+sum(X))/vr_f(alpha0,beta0)
    del2 <- (mn_f(alphab +n,betab+sum(X)) -  mn_f(alpha0,beta0))^2 / vr_f(alpha0,beta0)
    Rhat <- rhat * ( 1 - 1/(2/(del2 - 1) + rhat/(1+rhat)  ) ) 
    
    Rkhat<- mean(tail(my_M$M,10))/n
    
    return(list(U=U,uk=ku,Ub=Ub,ubk=kb,M=my_M$M,k_for_M=my_M$k,R = c(Rkhat, Rhat)))
  }
  
  Res<-list()
  all<-length(alpha_all)
  beg_time<-Sys.time()
  for(ii in 1:all){Res[[ii]] = myfunc(ii)}
  
  
  U<-numeric(0)
  uk<-numeric(0)
  Ub<-numeric(0)
  ubk<-numeric(0)
  M<-numeric(0)
  km<-numeric(0)
  Slp<-numeric(0)
  REst<-numeric(0)
  
  
  # Once M is calculated we can compute the slopes
  for(i in 1:all){
    U<-rbind(U,Res[[i]]$U)
    uk<-rbind(uk,Res[[i]]$uk)
    Ub<-rbind(Ub,Res[[i]]$Ub)
    ubk<-rbind(ubk,Res[[i]]$ubk)
    M<-rbind(M,Res[[i]]$M)
    km<-rbind(km,Res[[i]]$k_for_M)
    Slp<-c(Slp,lm(M[i,] ~ km[i,])[[1]][2])
    REst<-rbind(REst,Res[[i]]$R)
  }
  return(list(M=M,Slp=Slp,km=km,REst=REst))
}

if(plots_only!=TRUE){
  if(cl_node_type == "single"){
    library(doParallel); 
    num_cores=detectCores()-2;
    workers=makeCluster(num_cores,type="SOCK",outfile="test")
    ctype<-"rbind"
    #########################
  }else if(cl_node_type == "multiple"){
    #### Cluster ONLY ####
    library(Rmpi)
    library(doParallel)
    library(snow)
    num_cores = mpi.universe.size()-1
    workers=makeCluster(num_cores,type="MPI")
    ctype<-"rbind"
  }
  #workers=makeCluster(num_core,type="SOCK"); 
  registerDoParallel(workers)
  start_time<-Sys.time()
  res<-foreach(ii = 1:ave_reps) %dopar% myfunc_2(ii)
  end_time<-Sys.time()
  print(end_time-start_time)
  
  M_ave<-array(dim=c(ave_reps,length(alpha_all), length(res[[1]]$M[1,])   ))
  km_all<-array(dim=c(ave_reps,length(alpha_all),length(res[[1]]$M[1,])   ))
  Slp_ave<-matrix(nrow=ave_reps,ncol=length(alpha_all))
  REst<-array(dim=c(ave_reps,length(alpha_all),length(res[[1]]$REst[1,])))
  for(i_ave_reps in 1:ave_reps){
    M_ave[i_ave_reps,,]<-res[[i_ave_reps]]$M
    km_all[i_ave_reps,,]<-res[[i_ave_reps]]$km
    Slp_ave[i_ave_reps,]<-res[[i_ave_reps]]$Slp
    REst[i_ave_reps,,] <- res[[i_ave_reps]]$REst
  }
  
  ## MC CALC ##
  M_MC<-matrix(nrow=length(Delta_all),ncol=(k_plot-k_beg+1) )
  R_MC<-numeric(length(Delta_all))
  R_quick_par<-numeric(length(Delta_all))
  for(ii in 1:length(Delta_all)){
    # Prior parameters
    alpha0<-alpha_all[ii] #alpha0<-mn^2/vr
    beta0<-beta_all[ii]  #beta0<-mn/vr
    
    
    #par attempt
    reps_mc<-100000
    rep_block<-num_cores
    my_mc_fun<-function(ii_block){
      sum_X_k <- t(apply(matrix(rexp(n=k_max*reps_mc,rate=lambda),nrow=reps_mc,ncol=k_max),1,cumsum)) 
      post_beta<-beta0+sum_X_k
      post_beta_b<-betab+sum_X_k
      
      post_mean_diff_k <- colMeans((scale(1/post_beta,center=FALSE,scale=1/(alpha0 +1:k_max)) - lambda)^2)
      post_mean_diff_kb <- colMeans((scale(1/post_beta_b,center=FALSE,scale=1/(alphab  +1:k_max)) - lambda)^2)
      post_var_k<-colMeans(scale(1/post_beta^2,center=FALSE,scale=1/(alpha0  +1:k_max)  ))
      post_var_kb<-colMeans(scale(1/post_beta_b^2,center=FALSE,scale=1/(alphab  +1:k_max)  ))
      
      post_mse_k<-post_var_k + post_mean_diff_k #(post_mean_k - muhat)^2
      post_mse_kb<-post_var_kb + post_mean_diff_kb # (post_mean_kb - muhat)^2
      return(rbind(post_mse_k,post_mse_kb))
    }
    post_mse_k<-numeric(k_max)
    post_mse_kb<-numeric(k_max)
    st_time<-Sys.time()
    
    post_mse<-foreach(ii_block = 1:rep_block,.combine='+') %dopar% my_mc_fun(ii_block)
    
    post_mse_k<-post_mse[1,]/rep_block
    post_mse_kb<-post_mse[2,]/rep_block
    Sys.time() - st_time
    
    
    U<-post_mse_k[-(1:(k_beg-1))]; ku<-(k_beg):k_max
    Ub<-post_mse_kb[-(1:(k_beg-1))]; kb<-(k_beg):k_max
    ngrid=100000
    my_M<-find_M(U,ku,Ub,kb,ngrid,k=k_plot)
    
    M_MC[ii,] <- my_M$M
    
    R_MC[ii] <- mean(tail(my_M$M,10))/n
    
    rTrue <- vr_f(alphab +n,betab+n/lambda)/vr_f(alpha0,beta0)
    del2True <- (mn_f(alphab +n,betab+n/lambda) -  mn_f(alpha0,beta0))^2 / vr_f(alpha0,beta0)
    R_quick_par[ii] <- rTrue * ( 1 - 1/(2/(del2True - 1) + rTrue/(1+rTrue)  ) ) 
    
    
    #rm(list=c("sum_X_k","post_beta","post_beta_b"))
  }
  stopCluster(workers);
  if(cl_node_type == "multiple"){mpi.exit()}
}

#Plots
file_name1<-paste("FromCluster/exp_results/exp_rate_nall",n_all,"_reps",ave_reps,sep="")
if(cv_sample==TRUE & usetruth==FALSE){file_name1<-paste(file_name1,"_cv",sep="")}
if(usetruth==TRUE ){file_name1<-paste(file_name1,"_truth",sep="")}
if(perm==TRUE){file_name1<-paste(file_name1,"_perm",sep="")}
if(perm!=TRUE){file_name1<-paste(file_name1,"_boot",sep="")}
file_name<-paste(file_name1,".pdf",sep="")
if(plots_only==TRUE){load(paste(file_name1,".RData",sep=""))
}else{save.image(paste(file_name1,".RData",sep=""))}



# New Est
pdf(file=paste(file_name1,"REst_Box.pdf",sep=""),height=2,width=9)
par(mfrow=c(1,4),mar=c(2,2,.5,.5))
box_lim<-c(min(REst),max(REst))
for(i in 1:length(alpha_all)){
  REst_tmp<-c(REst[,i,])
  REst_grp<-factor(rep(c("RPlot","QuickEst"),each=dim(REst)[1]),levels=c("RPlot","QuickEst"))
  RPlt<-data.frame(REst_tmp,REst_grp)
  boxplot(REst_tmp~REst_grp,lex.order = FALSE, ylim=box_lim)
  abline(h=R_MC[i],col="red",lty=2,lwd=2)
}
dev.off()


# M Plot
pdf(file=paste(file_name1,"_ave_plots.pdf",sep=""),height=2,width=9)
par(mfrow=c(1,4),mar=c(2,2,.5,.5))
mplot_lim<-c(min(M_ave),max(M_ave))
for(i in 1:length(Delta_all)){
  M_plot<-as.matrix(M_ave[,i,])
  km<-as.matrix(km_all[,i,])
  #ylow<-min(M_plot);yhigh<-max(M_plot)
  ylow= min(M_ave); yhigh=max(M_ave);
  matplot(t(km),t(M_plot),type="l",#ylim =c(ylow,yhigh),
          ylim=mplot_lim,
          col="grey",lty=1,ylab="",xlab="")
  mn_vec<-colMeans(M_plot)
  points(km[i,],mn_vec,type="l",lwd=1.5)
  points(km[i,],M_MC[i,],type="l",lty=2,col="red")
}
dev.off()



# R plot vs R asym scatter
pdf(file=paste(file_name1,"REst_Scatter.pdf",sep=""),height=2,width=9)
par(mfrow=c(1,4),mar=c(2,2,.5,.5))
box_lim<-c(min(REst),max(REst))
for(i in 1:length(Delta_all)){
  REst_tmp<-c(REst[,i,])
  REst_grp<-factor(rep(c("RPlot","QuickEst"),each=dim(REst)[1]),levels=c("RPlot","QuickEst"))
  RPlt<-data.frame(REst_tmp,REst_grp)
  plot(RPlt$REst_tmp[RPlt$REst_grp=="RPlot"],RPlt$REst_tmp[RPlt$REst_grp=="QuickEst"],xlab="",ylab="")#,xlab="RFast",ylab="RPlot")
  abline(a=0,b=1)
}
dev.off()











