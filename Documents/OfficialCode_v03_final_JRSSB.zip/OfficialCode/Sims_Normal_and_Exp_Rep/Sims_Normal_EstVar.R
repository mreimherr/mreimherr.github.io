##########################
# Simulation scheme with normal data with known mean.
# We now repreat ths many times to see average results.
##########################

# Clean out workspace
rm(list=ls())
plots_only<-FALSE
ave_reps<-100
#cl_node_type <- "multiple"
cl_node_type <- "single"

#library(abind)
source("find_M.R")

# We set the seed so that all plots are reproducible
myseed<-2012
set.seed(myseed)

test_seed<-FALSE
mn_X<-0.85 # only used for testing, reweights data to have specific sample mean
mn_Xcv<-0.85

# n is the sample size of the data
# Normal is super robust against sample size
# sampling with replacement makes it very smooth
n_all<-100

usewt<-FALSE # weight proposed by XL, this reweights the bias by  1/(1+k/n)
cv_sample<-FALSE # if true then sample is divided 
usetruth<-FALSE # if true then truth is used, cv_sample is ignored
# exact U and M, cv_sample and use_truth are ignored
perm<-FALSE # True=permutation, False = bootstrap

cv_prop<-0.5 # prop to leave out for estimating "truth"
if(cv_sample==TRUE & usetruth!=TRUE ){
  n_cv<-round(cv_prop*n_all)
  n<-n_all - n_cv
}else{
  n<-n_all
}


# k_max controls the largest value of k when
# computing the uncertaing functions U(k)
# k_plot<-200
# k_max<- 300
k_plot<- n_all/2
k_max<- n_all

# Number of k to plot
# note that we actually plot k_plot/2
# so plan accordingly 


# Number of bootstrap samples
reps<-100000

# true paramters values
mu<-1
sigma<-1

## We take a normal prior on mu and assume sigma is known. 
## hyper parameters 
# lambda is the prior mean, tau is the prior sd
# r/Delta parametrization
Delta_all<-c(0,0.5,1,1.25)
r_all<-c(1,1,1,1)*.05
# New Parametrization
# r = (sigma^2/n) / tau^2 ; del2 = (mu -  lambda)^2 / tau^2
tau_all = sqrt( sigma^2 / (r_all * n))
lambda_all = mu + tau_all*Delta_all 

## We also take a normal prior on mu for the baseline.
# under the baseline we take taub to be infinte
lambdab<-1

#for(i_ave_reps in 1:ave_reps){
#foreach(i_ave_reps==1:ave_reps) %dopar% {
myfunc_2<-function(i_ave_reps){  
  # Generate Data
  X<- rnorm(n,mean= mu, sd = sigma) 
  if(test_seed==TRUE){X<-mn_X*X/mean(X)}
  if(cv_sample==TRUE & usetruth!=TRUE ){
    X_cv<-rnorm(n_cv,mean= mu, sd = sigma)  
    if(test_seed==TRUE){X_cv<-mn_Xcv*X_cv/mean(X_cv)}
  }
  
  
  # Set up Us and M
  
  # We now setup a function that we can parallelize
  # this function computes the Us for a given prior
  myfunc<-function(ii){
    
    # prior hyper parameters
    lambda <- lambda_all[ii]
    tau <- tau_all[ii]
    
    # translate to prior mean and sd
    prior_mean<- lambda
    prior_var<- tau^2
    
    # we keep track of the posterior means and variance
    # for the the prior and baseline
    post_mean_diff_k<-numeric(0)
    post_mean_diff_kb<-numeric(0)
    post_var_k<-numeric(0)
    post_var_kb<-numeric(0)
    
    # the posterior mean using all of the data and basline
    # is just the sample mean
    muhat<-mean(X)
    sighat<-sd(X)
    if(cv_sample==TRUE & usetruth!=TRUE ){muhat<-mean(X_cv)}
    if(usetruth==TRUE){muhat=mu}
    
    
    sum_X_k <- t(apply(matrix(sample(X,size=k_max*reps,replace=!perm),nrow=reps,ncol=k_max),1,cumsum)) 
    post_lambda <-  scale(((lambda/tau^2+sum_X_k/sighat^2)), center=FALSE, scale=(1/tau^2+ (1:k_max)/sighat^2)) 
    post_lambdab<-scale(sum_X_k,center=FALSE,scale=1:k_max)  
    
    
    post_mean_diff_k<-colMeans((post_lambda - muhat)^2)
    post_var_k<-(1/(1/tau^2+ (1:k_max)/sighat^2))
    post_mean_diff_kb<-colMeans((post_lambdab - muhat)^2)
    post_var_kb<- sighat^2/(1:k_max)
    post_mse_k<-post_var_k + post_mean_diff_k
    post_mse_kb<-post_var_kb + post_mean_diff_kb 
    prior_mse<-prior_var +(prior_mean - muhat)^2
    
    
    
    U<-post_mse_k
    Ub<-post_mse_kb
    my_M<-find_M(U,1:k_max,Ub,1:k_max,ngrid=60000,k=k_plot)
    
    # Approximation
    MAT_rep<-1000
    X_MAT<-matrix(rnorm(n*MAT_rep,mean=mu,sd=sighat),ncol=MAT_rep)
    rhat<-rep((sighat^2/n) / tau^2,times=MAT_rep )
    del2<-(colMeans(X_MAT) - lambda)^2/tau^2
    del2T<-(mu - lambda)^2/tau^2; rhatT<-rhat[1]
    Rhat <- rhat * ( 1 - 1/(2/(del2 - 1) + rhat/(1+rhat)  ) ) 
    RTru<-  rhatT * ( 1 - 1/(2/(del2T - 1) + rhatT/(1+rhatT)  ) ) 
    hist(Rhat);abline(v=RTru,col="red")
    
    rhat <- (sighat^2/n) / tau^2
    del2 <- (mean(X) -  lambda)^2 / tau^2
    Rhat <- rhat * ( 1 - 1/(2/(del2 - 1) + rhat/(1+rhat)  ) ) 
    
    Rkhat<- mean(tail(my_M$M,10))/n
    
    
    return(list(U=U,uk=1:k_max,Ub=Ub,ubk=1:k_max,M=my_M$M,k_for_M=my_M$k,R = c(Rkhat, Rhat)))
  }
  
  ### WARNING: takes a few minutes to run
  ## Each loop uses a different set of parameters
  ## Returns values 1:k_plot/2
  #
  Res<-list()
  all<-length(lambda_all)
  for(ii in 1:all){Res[[ii]] = myfunc(ii)}
  
  
  U<-numeric(0)
  uk<-numeric(0)
  Ub<-numeric(0)
  ubk<-numeric(0)
  M<-numeric(0)
  km<-numeric(0)
  Slp<-numeric(0)
  REst<-numeric(0)
  
  
  
  # Once M is calculated we can compute the slopes
  for(i in 1:all){
    U<-rbind(U,Res[[i]]$U)
    uk<-rbind(uk,Res[[i]]$uk)
    Ub<-rbind(Ub,Res[[i]]$Ub)
    ubk<-rbind(ubk,Res[[i]]$ubk)
    M<-rbind(M,Res[[i]]$M)
    km<-rbind(km,Res[[i]]$k_for_M)
    Slp<-c(Slp,lm(M[i,] ~ km[i,])[[1]][2])
    REst<-rbind(REst,Res[[i]]$R)
  }
  return(list(M=M,Slp=Slp,km=km,REst=REst))
}


if(plots_only!=TRUE){
  if(cl_node_type == "single"){
    library(doParallel); 
    num_cores=detectCores()-2;
    workers=makeCluster(num_cores,type="SOCK",outfile="test")
    ctype<-"rbind"
    #########################
  }else if(cl_node_type == "multiple"){
    #### Cluster ONLY ####
    library(Rmpi)
    library(doParallel)
    library(snow)
    num_cores = mpi.universe.size()-1
    workers=makeCluster(num_cores,type="MPI")
    ctype<-"rbind"
  }
  #workers=makeCluster(num_core,type="SOCK"); 
  registerDoParallel(workers)
  start_time<-Sys.time()
  res<-foreach(ii = 1:ave_reps) %dopar% myfunc_2(ii)
  end_time<-Sys.time()
  print(end_time-start_time)
  
  
  M_ave<-array(dim=c(ave_reps,length(lambda_all),k_plot))
  km_all<-array(dim=c(ave_reps,length(lambda_all),k_plot))
  Slp_ave<-matrix(nrow=ave_reps,ncol=length(lambda_all))
  REst<-array(dim=c(ave_reps,length(lambda_all),length(res[[1]]$REst[1,])))
  for(i_ave_reps in 1:ave_reps){
    M_ave[i_ave_reps,,]<-res[[i_ave_reps]]$M
    km_all[i_ave_reps,,]<-res[[i_ave_reps]]$km
    Slp_ave[i_ave_reps,]<-res[[i_ave_reps]]$Slp
    REst[i_ave_reps,,] <- res[[i_ave_reps]]$REst
  }
  
  ## MC CALC ##
  M_MC<-matrix(nrow=length(lambda_all),ncol=k_plot)
  R_MC<-numeric(length(lambda_all))
  R_quick_par<-numeric(length(lambda_all))
  for(ii in 1:length(lambda_all)){
    lambda <- lambda_all[ii]
    tau <- tau_all[ii]
    # translate to prior mean and sd
    prior_mean<- lambda
    prior_var<- tau^2
    
    # we keep track of the posterior means and variance
    # for the the prior and baseline
    post_mean_diff_k<-numeric(0)
    post_mean_diff_kb<-numeric(0)
    post_var_k<-numeric(0)
    post_var_kb<-numeric(0)
    
    # the posterior mean using all of the data and basline
    # is just the sample mean
    
    # calculate U and Ub for each k
    reps_mc<-100000
    rep_block<-num_cores
    my_mc_fun<-function(ii_block){
      
      sum_X_k <- t(apply(matrix(rnorm(n=k_max*reps_mc,mean=mu,sd=sigma),nrow=reps_mc,ncol=k_max),1,cumsum)) 
      post_lambda <-  scale(((lambda/tau^2+sum_X_k/sigma^2)), center=FALSE, scale=(1/tau^2+ (1:k_max)/sigma^2)) 
      post_lambdab<-scale(sum_X_k,center=FALSE,scale=1:k_max)  
      
      
      post_mean_diff_k<-colMeans((post_lambda - mu)^2)
      #post_mean_diff_k<-colMeans(t(scale(t(post_lambda), center=sum_X_k[,k_max]/k_max,scale=FALSE))^2)
      post_var_k<-(1/(1/tau^2+ (1:k_max)/sigma^2))
      post_mean_diff_kb<-colMeans((post_lambdab - mu)^2)
      #post_mean_diff_kb<-colMeans(t(scale(t(post_lambdab), center=sum_X_k[,k_max]/k_max,scale=FALSE))^2)
      post_var_kb<- sigma^2/(1:k_max)
      
      post_mse_k<-post_var_k + post_mean_diff_k
      post_mse_kb<-post_var_kb + post_mean_diff_kb 
      return(rbind(post_mse_k,post_mse_kb))
    }
    post_mse_k<-numeric(k_max)
    post_mse_kb<-numeric(k_max)
    st_time<-Sys.time()
    
    post_mse<-foreach(ii_block = 1:rep_block ,.combine='+') %dopar% my_mc_fun(ii_block)
    
    post_mse_k<-post_mse[1,]/rep_block
    post_mse_kb<-post_mse[2,]/rep_block
    Sys.time() - st_time
    
    
    U<-post_mse_k
    Ub<-post_mse_kb
    my_M<-find_M(U,1:k_max,Ub,1:k_max,ngrid=100000,k=k_plot)
    M_MC[ii,] <- my_M$M
    
    R_MC[ii] <- mean(tail(my_M$M,10))/n
    
    rTrue <- (sigma^2/n) / tau^2
    del2True <- (mu -  lambda)^2 / tau^2
    R_quick_par[ii]<- rTrue * ( 1 - 1/(2/(del2True - 1) + rTrue/(1+rTrue)  ) ) 
  }
  stopCluster(workers)
  if(cl_node_type == "multiple"){mpi.exit()}
}



## Plots
if(plots_only==TRUE){file_name1<-paste("FromCluster/normal_estsd_results/normal_nall",n_all,"_reps",ave_reps,sep="")
}else{file_name1<-paste("FromCluster/normal_estsd_results/normal_nall",n_all,"_reps",ave_reps,sep="")}

if(cv_sample==TRUE & usetruth==FALSE){file_name1<-paste(file_name1,"_cv",sep="")}
if(usetruth==TRUE ){file_name1<-paste(file_name1,"_truth",sep="")}
if(perm==TRUE ){file_name1<-paste(file_name1,"_perm",sep="")}
if(perm!=TRUE ){file_name1<-paste(file_name1,"_boot",sep="")}
file_name<-paste(file_name1,".pdf",sep="")
if(plots_only==TRUE){load(paste(file_name1,".RData",sep=""))
}else{save.image(paste(file_name1,".RData",sep=""))}


# New Est
pdf(file=paste(file_name1,"REst_Box.pdf",sep=""),height=2,width=9)
par(mfrow=c(1,4),mar=c(2,2,.5,.5))
box_lim<-c(min(REst),max(REst))
for(i in 1:length(lambda_all)){
  REst_tmp<-c(REst[,i,])
  REst_grp<-factor(rep(c("RPlot","QuickEst"),each=dim(REst)[1]),levels=c("RPlot","QuickEst"))
  RPlt<-data.frame(REst_tmp,REst_grp)
  boxplot(REst_tmp~REst_grp,lex.order = FALSE, ylim=box_lim)
  abline(h=R_MC[i],col="red",lty=2,lwd=2)
  #  lines(y=c(R_MC[i],R_MC[i]),x=c(.6,1.4),col="red",lty=2)
  #  lines(y=c(R_quick_par[i],R_quick_par[i]),x=c(1.6,2.4),col="red",lty=2)
}
dev.off()


# M Plot
pdf(file=paste(file_name1,"_ave_plots.pdf",sep=""),height=2,width=9)
par(mfrow=c(1,4),mar=c(2,2,.5,.5))
mplot_lim<-c(min(M_ave),max(M_ave))
for(i in 1:length(lambda_all)){
  M_plot<-as.matrix(M_ave[,i,])
  km<-as.matrix(km_all[,i,])
  #ylow<-min(M_plot);yhigh<-max(M_plot)
  #ylow= min(M_ave); yhigh=max(M_ave);
  ylow = 0; yhigh=12
  matplot(t(km),t(M_plot),type="l",#ylim =c(ylow,yhigh),
          ylim=mplot_lim,
          col="grey",lty=1,ylab="",xlab="")
  mn_vec<-colMeans(M_plot)
  points(km[i,],mn_vec,type="l",lwd=1.5)
  points(1:k_plot,M_MC[i,],type="l",lty=2,col="red")
}
dev.off()


# R plot vs R asym scatter
pdf(file=paste(file_name1,"REst_Scatter.pdf",sep=""),height=2,width=9)
#par(mfrow=c(1,4),mar=c(4.25,4.25,.5,.5))
par(mfrow=c(1,4),mar=c(2,2,.5,.5))
box_lim<-c(min(REst),max(REst))
for(i in 1:length(lambda_all)){
  REst_tmp<-c(REst[,i,])
  REst_grp<-factor(rep(c("RPlot","QuickEst"),each=dim(REst)[1]),levels=c("RPlot","QuickEst"))
  RPlt<-data.frame(REst_tmp,REst_grp)
  #boxplot(REst_tmp~REst_grp,lex.order = FALSE, ylim=box_lim)
  plot(RPlt$REst_tmp[RPlt$REst_grp=="RPlot"],RPlt$REst_tmp[RPlt$REst_grp=="QuickEst"],xlab="",ylab="")#,xlab="RFast",ylab="RPlot")
  abline(a=0,b=1)
  #abline(h=R_MC[i],col="red",lty=2,lwd=2)
}
dev.off()
