rm(list=ls())
#library(fdrtool)
library(fda)
library(arm)
library(doParallel); 
num_cores=detectCores()-2;


#1 +3 +7 + 6 + 6 + 4 + 3+ 4+ 1 + 1 = 36
X1<-c(rep(0,times=36),
      rep(0.5, times = 2),
      rep(1, times = 4),
      rep(1.5, times = 6),
      rep(2, times = 7))

X2<-c(-3,
      rep(-2.5, times = 3),
      rep(-2, times = 7),
      rep(-1.5, times = 6),
      rep(-1, times = 6),
      rep(-0.5, times = 4),
      rep(0, times = 3),
      rep(0.5, times = 4),
      rep(1, times = 1),
      rep(1.5, times = 1),
      #
      rep(-1.5, times = 1),
      rep(-1, times = 1),
      #
      rep(-1, times = 1),
      rep(0, times = 1),
      rep(0.5, times = 1),
      rep(1, times = 1),
      #
      rep(-0.5, times = 1),
      rep(0, times = 1),
      rep(0.5, times = 1),
      rep(1, times = 1),
      rep(1.5, times = 2),
      #
      rep(-2, times = 1),
      rep(-1, times = 1),
      rep(0.5, times = 1),
      rep(1, times = 4)
)

Y<-c(rep(0,times=31),
     rep(1,times=5),
     rep(0,times=2),
     rep(0,times=2),
     rep(1,times=2),
     rep(1,times=6),
     rep(0,times=2),
     rep(1,times=5)
)

X1<-(X1-mean(X1))/(2*sd(X1))
X2<-(X2-mean(X2))/(2*sd(X2))


glm1<-glm(Y~X1,family=binomial(link="logit"))





# Vary these two for the paper
# Note DF is the degrees of freedom for both the baseline an prior
DFp=1
DFb=Inf
PScaleb <- 100

PScale_all <-c(2.5, 5, 10)
all<-length(PScale_all)

#DF=Inf
#bglm1<-bayesglm(Y~ X1 + X2, family = binomial(link="logit"),prior.df=DF,prior.scale=1000)
bglm1<-bayesglm(Y~ X1, family = binomial(link="logit"),prior.df=DFb,prior.scale=PScaleb,prior.scale.for.intercept=1000)


## R Approx
bglm_base<-bayesglm(Y~ X1, family = binomial(link="logit"),prior.df=DFb,prior.scale=PScaleb,prior.scale.for.intercept=1000)
sbglm_base<-summary(bglm_base)
R_hat <- numeric(0)
for(ip in 1:length(PScale_all)){
  PScale = PScale_all[ip]
  bglm_prior<-bayesglm(Y~ X1, family = binomial(link="logit"),prior.df=DFp,prior.scale=PScale,prior.scale.for.intercept=1000)
  #sbglm_prior<-summary(bglm_prior)
  var_mu_post_all<-se.coef(bglm_prior)[2]^2
  var_mu_post_base_all<-se.coef(bglm_base)[2]^2
  mean_mu_post_all<-bglm_prior$coefficients[2]
  mean_mu_post_base_all<-bglm_base$coefficients[2]
  p1_hat<-var_mu_post_base_all/(var_mu_post_base_all+PScale^2)
  # With Baseline
  Delta2_hat<-(0 - mean_mu_post_base_all)^2/PScale^2
  R_hat<-c(R_hat,(p1_hat/(1-p1_hat))*(1-(Delta2_hat-1)/(2+p1_hat*(Delta2_hat-1))))
}
mymat<-cbind(PScale_all,round(R_hat,4),round(c(2.5,2,1)/55,4))
rownames(mymat)<-NULL
colnames(mymat)<-c("prior scale","R hat","R hat from Plot")
#swapping to normal didnt make any diference

theta1<-bglm1$coef[2]
#theta2<-bglm1$coef[3]


cut<-10
k_all<-64 - cut
#sub1<-sample((1:55)[Y==1],size=k)
#sub2<-sample((1:55)[Y==0],size=2*k)
#sub<-c(sub1,sub2)

#upping reps from 1000 to 10000 helped a lot
reps<-100



U_all<-matrix(nrow=length(PScale_all),ncol=(k_all-cut))
Ub_all<-matrix(nrow=length(PScale_all),ncol=(k_all-cut))
M_all<-matrix(nrow=length(PScale_all),ncol=(k_all/2))

for(ii in 1:length(PScale_all)){
  PScale<-PScale_all[ii]
  
  U_theta1<-numeric(k_all-cut)
  U_theta1b<-numeric(k_all-cut)
  U_theta1_all<-matrix(nrow=(k_all-cut),ncol=reps)
  U_theta1_allb<-matrix(nrow=(k_all-cut),ncol=reps)
  
  
  #U_theta2<-numeric(k_all-cut)
  #U_theta2b<-numeric(k_all-cut)
  #U_theta2_all<-matrix(,nrow=(k_all-cut),ncol=reps)
  #U_theta2_allb<-matrix(,nrow=(k_all-cut),ncol=reps)
  
  mean1<-matrix(nrow=(k_all-cut),ncol=reps)
  mean1b<-matrix(nrow=(k_all-cut),ncol=reps)
  var1<-matrix(nrow=(k_all-cut),ncol=reps)
  var1b<-matrix(nrow=(k_all-cut),ncol=reps)
  
  #mean2<-matrix(,nrow=(k_all-cut),ncol=reps)
  #mean2b<-matrix(,nrow=(k_all-cut),ncol=reps)
  #var2<-matrix(,nrow=(k_all-cut),ncol=reps)
  #var2b<-matrix(,nrow=(k_all-cut),ncol=reps)
  
  for(k in (1+cut):k_all){
    #for(i in 1:reps){
    myfun<-function(){
      #sub<-sample((1:55),size=k,replace=TRUE) # variance drops too slowly with replacement
      sub<-sample((1:55),size=k,replace=FALSE)
      Y.tmp<-Y[sub]
      X1.tmp<-X1[sub]
      #X2.tmp<-X2[sub]
      
      #bglm.tmpb<-bayesglm(Y.tmp~ X1.tmp + X2.tmp, family = binomial(link="logit"),prior.df=DF,prior.scale=1000,prior.scale.for.intercept=1000)
      bglm.tmpb<-bayesglm(Y.tmp~ X1.tmp, family = binomial(link="logit"),prior.df=DFb,prior.scale=PScaleb,prior.scale.for.intercept=1000)
      sbglm.tmpb<-summary(bglm.tmpb)
      
      #bglm.tmp<-bayesglm(Y.tmp~ X1.tmp + X2.tmp, family = binomial(link="logit"),prior.df=DF,prior.scale=2.5,prior.scale.for.intercept=1000)
      #bglm.tmp<-bayesglm(Y.tmp~ X1.tmp, family = binomial(link="logit"),prior.df=DF,prior.scale=2.5)
      bglm.tmp<-bayesglm(Y.tmp~ X1.tmp, family = binomial(link="logit"),prior.df=DFp,prior.scale=PScale,prior.scale.for.intercept=1000)
      sbglm.tmp<-summary(bglm.tmp)
      
      #mean1[(k-cut),i]<-bglm.tmp$coefficients[2]
      #mean1b[(k-cut),i]<-bglm.tmpb$coefficients[2]
      #var1b[(k-cut),i]<-se.coef(bglm.tmpb)[2]^2
      #var1[(k-cut),i]<-se.coef(bglm.tmp)[2]^2
      
      mean1<-bglm.tmp$coefficients[2]
      mean1b<-bglm.tmpb$coefficients[2]
      var1b<-se.coef(bglm.tmpb)[2]^2
      var1<-se.coef(bglm.tmp)[2]^2
      
      
      #mean2[(k-cut),i]<-bglm.tmp$coefficients[3]
      #mean2b[(k-cut),i]<-bglm.tmpb$coefficients[3]
      #var2b[(k-cut),i]<-se.coef(bglm.tmpb)[3]^2
      #var2[(k-cut),i]<-se.coef(bglm.tmp)[3]^2
      
      #U_theta1_allb[(k-cut),i]<-var1b[(k-cut),i]+(mean1b[(k-cut),i]-theta1)^2
      #U_theta1_all[(k-cut),i]<-var1[(k-cut),i]+(mean1[(k-cut),i]-theta1)^2
      #U_theta2_allb[(k-cut),i]<-var2b[(k-cut),i]+(mean2b[(k-cut),i]-theta2)^2
      #U_theta2_all[(k-cut),i]<-var2[(k-cut),i]+(mean2[(k-cut),i]-theta2)^2
      
      U_theta1_allb<-var1b+(mean1b-theta1)^2
      U_theta1_all<-var1+(mean1-theta1)^2
      
      return(c(U_theta1_allb, U_theta1_all))
    }
    #}
    workers=makeCluster(num_cores,type="SOCK",outfile="test");registerDoParallel(workers)
    clusterEvalQ(workers,library(arm))
    tmp<-foreach(i = 1:reps,.combine=rbind) %dopar% myfun()
    stopCluster(workers)
    #U_theta1b[k-cut]<-median(U_theta1_allb[k-cut,])
    #U_theta1[k-cut]<-median(U_theta1_all[k-cut,])
    
    U_theta1b[k-cut]<-median(tmp[,1])
    U_theta1[k-cut]<-median(tmp[,2])
    
    #U_theta2[k-cut]<-median(U_theta2_all[k-cut,])
    #U_theta2b[k-cut]<-median(U_theta2_allb[k-cut,])
  }
  
  #tbl<-cbind(U_theta1, U_theta1b, U_theta2, U_theta2b)
  #save(tbl,file="/Users/Matthew/Desktop/CurrentProjects/2011_MeNiRe/application/Us1")
  
  #trim = 0.0
  #mean1_all<-apply(mean1,1,median)
  #mean1b_all<-apply(mean1b,1,median)
  #var1_all<-apply(var1,1,median)
  #var1b_all<-apply(var1b,1, median)
  
  #U1<-var1_all + (mean1_all - theta1)^2
  #U1b<-var1b_all + (mean1b_all - theta1)^2
  
  #U_theta1b<-U1b
  #U_theta1<-U1
  #spread1<-apply(mean1,1,quantile,probs=0.75) - apply(mean1,1,quantile,probs=0.25)
  #spread1b<-apply(mean1b,1,quantile,probs=0.75) - apply(mean1b,1,quantile,probs=0.25)
  
  #Data_List<-list(mean1_all,mean1b_all,var1_all,var1b_all)
  
  #pts<-4:(length(U_theta1b_all)+3)
  #plot(pts,mean1b_all,ylim=c(0,7))
  #abline(h=theta1,col="red")
  #points(pts,mean1_all,pch=2)
  
  #par(mfrow=c(1,2))
  #plot(pts,U1b,ylab="Scale = 1000")
  #plot(pts,U1,pch=2,ylab="Scale = ")
  
  pts<-(1+cut):(length(U_theta1b)+cut)
  #dev.new(width=5,height=5)
  #plot(pts,U1b,ylim=c(0,max(U1)),xlab="",ylab="")
  #points(pts,U1,pch=2)
  #leg = c(paste("Scale = ",PScale,sep=""),paste("Scale = ",PScaleb,sep=""))
  #legend(30,(.75*max(U1)),legend=leg,pch=c(2,1))
  
  
  #mean2_all<-apply(mean2,1,median)
  #mean2b_all<-apply(mean2b,1,median)
  
  post_mse_kb<-U_theta1b
  post_mse_k<-U_theta1
  lb<-numeric(0)
  ub<- numeric(0)
  #ub0<-min(which(post_var_kb<prior_var)[-1]) 
  #lb0<-max(which(post_mse_kb>=prior_mse))
  #if(lb0==-Inf)(lb0=0)
  #ub0<-lb0+1
  impsamp<-numeric(0)
  for(j in (1):(k_all/2)){
    #ub[j]<-min(which(post_var_kb<post_var_k[j])) - j 
    #if(post_mse_kb[3]>post_mse_k[j]){
    tmp<-max(which(post_mse_kb>post_mse_k[j])) # find last time prior is above baseline
    if(tmp==-Inf){tmp<-1}
    #}else{tmp<-3}
    lb[j]<-tmp - j 
    impsamp[j]<-lb[j]+(post_mse_kb[tmp]-post_mse_k[j])/(post_mse_kb[tmp]-post_mse_kb[tmp+1])
    remove(tmp)
  }
  ub<-lb+1
  # inty<-max(c(prior_mse,post_mse_kb[3:k_plot]))
  
  
  #dev.new(width=5,height=5)
  #lm1<-lm(impsamp[1:7]~c(4:(7+3)))
  #plot(c(4:(7+3)),impsamp[1:7],xlab="",ylab="")
  #lm1<-lm(impsamp~c(4:(k_all/2+3)))
  #plot(c(4:(k_all/2+3)),impsamp,xlab="",ylab="")
  #abline(a=lm1$coef[1],b=lm1$coef[2])
  
  
  
  #abline(a=lm1$coef[1],b=lm1$coef[2])
  
  # tmpx<-(1:(k_plot/2))
  # tmp<-lm(impsamp ~ tmpx)
  # tmplab<-paste("k (Slope = ",round(tmp[[1]][2],digits=4),")",sep="")
  # plot(impsamp,main="",xlab=tmplab,ylab="Imputed Sample Size")
  # abline(tmp)
  # lnsm<-ksmooth(tmpx,impsamp,kernel="normal",bandwidth=30)
  # points(lnsm,type="l",col=2,lwd=2)
  # abline(h=-53,col=2)
  # axis(4,at=-53)
  # remove(tmp)
  # remove(tmpx) 
  
  #U_all[ii,]<-U1
  #Ub_all[ii,]<-U1b
  U_all[ii,]<-U_theta1
  Ub_all[ii,]<-U_theta1b
  M_all[ii,]<-impsamp
  
}

Slp<-numeric(0)
for(j in 1:length(PScale_all)){
  tmpx<-(1+cut):(k_all/2+cut)
  Slp[j]<-lm(M_all[j,]~tmpx)$coef[2]
}


basis_Fd<-create.bspline.basis(c((1+cut),(k_all/2+cut)),50)
par_Fd<-fdPar(basis_Fd,lambda=2)
file<-paste("App_M_","dfb_",DFb,"_dfp_",DFp,"_Scale_",PScaleb,".pdf",sep="")
pdf(file,width=6,height=6)
ltmp<-sprintf("%.1f",round(PScale_all,2))
ylm <- c(min(M_all),max(M_all))
plot((1+cut):(k_all/2+cut),M_all[1,],xlab="",ylab="",pch=1,col=1,ylim = ylm)
tmp<-smooth.monotone((1+cut):(k_all/2+cut),M_all[1,],par_Fd,dbglev=0)  
plot(tmp$yhatfd,add=TRUE)
for(j in 2:length(PScale_all)){
  points((1+cut):(k_all/2+cut),M_all[j,],xlab="",ylab="",pch=j,col=j)
  tmp<-smooth.monotone((1+cut):(k_all/2+cut),M_all[j,],par_Fd,dbglev=0)  
  plot(tmp$yhatfd,add=TRUE,col=j)
}
leg<-paste("Scale=",PScale_all)
legend("topright",legend=leg,pch=1:all,col=1:all)
dev.off()


#dev.new(width=6,height=6)
#ltmp<-sprintf("%.1f",round(PScale_all,2))
#ylm <- c(min(M_all),max(M_all))
#plot((1+cut):(k_all/2+cut),M_all[1,],xlab="",ylab="",pch=1,col=1,ylim = ylm)
#tmp<-lm(M_all[1,]~ tmpx)
#abline(tmp)
#for(j in 2:length(PScale_all)){
#	points((1+cut):(k_all/2+cut),M_all[j,],xlab="",ylab="",pch=j,col=j)
#	#tmp<-lm(M_all[j,]~ tmpx)
#	#abline(tmp,col=j)
#	mfit<-smooth.monotone(tmpx,M_all[j,])
#	lpred<-predict(lfit)
#	points((1+cut):(k_all/2+cut),lpred,col=j,typ="l")
#}
#leg<-paste("Scale=",PScale_all)
#legend(x=21.5,y=1.5,legend=leg,pch=1:all,col=1:all,bg='white')






